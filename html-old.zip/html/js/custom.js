$(".close-menu").click(function(){
	$(".side--menu").toggleClass("close--side--menu");
	$(".close-menu").toggleClass("open-menu");
});